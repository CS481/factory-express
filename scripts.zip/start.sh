#!/bin/bash
export DB_USR=dbuser
export DB_PWD=6100!recumbentBike
export DB_NAME=SimFactory
export DB_HOST=cluster0.hgu8w.mongodb.net
export BCRYPT_ROUNDS=8 # Use less rounds to make tests run faster
node bin/www.js