# Simulation Factory Express

## Run
Execute `npm start` from the command line

## Test
Execute `npm test` from the command line
Note that error messages will correspond to automatically generated test files in the 'lib' directory